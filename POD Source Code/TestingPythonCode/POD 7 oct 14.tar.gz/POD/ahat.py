'''
/* ahat.cpp
*
*/
#include "stdafx.h"
#include <math.h>
#include <search.h>
#include "PodDoc.h"
#include "XlControl.h"
#include "excel8.h"
#include "linreg.h"
#include "matrix.h"
'''
from math import *
'''
CString funcstr(CString v, int iopt);
bool IsCustom();
CString a_str();
CString r_str();
double a_fwd(double v);
double a_inv(double v);
double r_fwd(double v);
double r_inv(double v);
'''
from funcr import *
'''
// defined in alogam.cpp
double alogam(double x);
// defined in betain.cpp
double betain(double x, double p, double q, double beta);
// defined in phinv.cpp
double phinv(double p);
'''
from alogam import *
from betain import *
from phinv import *
'''
// defined in Info.cpp
void PutValue(int row, int col, double value);

// defined in mdnord.cpp
double mdnord(double x);
'''
from mdnord import *
'''
double leqslv(CMatrix &rj, double *dd);
'''
from leqslv import *
'''

// defined in smtxinv.cpp
double smtxinv(CMatrix &x, CMatrix &xi);
'''
from smtxinv import *
'''
// defined in sysolv.cpp
int ahat_sysolv(double *x, CMatrix &jb, double *fnorm);
'''
from sysolv import *
'''


// defined in nonlinear.cpp
int ahat_nonlinear_sysolv(double *x, CMatrix &jb, double *fnorm);

extern CPodDoc *pDoc;
'''

if __name__ == '__main__':
    print('alogam(23.2) '+str(alogam(23.2)))
    print('betain(.1,.2,.3,.4) '+str(betain(.1,.2,.3,.4)))
    print('phint test')
    for i in range(11) :
        if i == 0:
            x = 0.0001;
        elif i ==  10:
            x = 0.9999;
        else:
            x = 0.1*i;
        y = phinv(x);
        print("%9.4f\t %18.12f" % (x, y));
    print('mdnord(23.2) '+str(mdnord(23.2)))
    matrix = [[4,2],[6,1]]
    dd = [2,1]
    print ['matrix'+str(matrix)]
    print ['vector'+str(dd)]
    print ['tdleq(matrix,vector)'+str(tdleq(matrix,dd))]
    
    x = [[2,2,3],[4,5,6],[7,8,9]]
    print ("x: "+ str(x))

    xi = [[2,2,3],[4,5,6],[7,8,9]]
    print ("xi: "+ str(xi))

    deter, xi = smtxinv(x, xi)

    print ("x = [[1,2,3],[4,5,6],[7,8,9]]")
    print ("deter, xi = smtxinv(x)")
    print ("deter: " + str(deter))
    print ("xi: " + str(xi))
    
    print ['leqslv(x,[3,8,4.2])'+str(leqslv(x,[3,8,4.2]))]
    
    
    
    
    
    

