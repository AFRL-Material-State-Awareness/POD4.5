/* CrackData.cpp
*
*/
#include "stdafx.h"
#include <search.h>
#include "podDoc.h"
#include "XlControl.h"
#include "excel8.h"

// defined in funcr.cpp
bool IsCustom(); 
double a_fwd(double v);


//////////////////////////////////////////////////////////////////////////////
// CInspection class

CInspection::CInspection()
{
	flag = IF_Missing;
}


///////////////////////////////////////////////////////////////////////////////
// CrackData class

CrackData::CrackData()
{
	rdata = 0;
}

CrackData::~CrackData()
{
	delete [] rdata;
}

void CrackData::Init(int n)
{
	if (rdata) delete [] rdata;
	rdata = new CInspection[n];
	nsets = n;
}


void CrackData::Parse(int row, int flaw_column, int data_column)
{
	int j;
	Range range;
	Interior interior;
	// read crack size from flaw_column
	data_row = row;
	range = xl.GetRange(row,flaw_column);
	size = range.GetValue();
	interior = range.GetInterior();
	ColorIndex = interior.GetColorIndex();
	bValid = V_VT(&size)==VT_R8;
	if (bValid) {
		crksize = V_R8(&size);
		crkf = 0.0;
		// invalidate cracks with non-positive crack sizes
		bValid = crksize>0.0;
	}
	// read inspection data
	count = 0;
	for (j=0; j<nsets; j++) {
		range = xl.GetRange(row,j+data_column);
		rdata[j].v = range.GetValue();
		interior = range.GetInterior();
		rdata[j].ColorIndex = interior.GetColorIndex();
		if (rdata[j].IsIncluded()) count++;
	}
}


///////////////////////////////////////////////////////////////////////////////
// CPodDoc functions


BOOL CPodDoc::GetData()  //BWH Working Here
{
	int i, j, n;
	COleVariant v;
	Range range;
	CString str;

	// Get Data worksheet
	if (xl.GetWorkbookCount()<=0) return FALSE;
	if (!xl.GetSheet("Data")) {
		AfxMessageBox("No Excel worksheet called \"Data\"");
		return FALSE;
	}

	// Count columns, allow empty column-headers if less than start of data
	n = 1;
	while (1) {
		v = xl.GetValue(1,n);
		if (V_VT(&v)!=VT_BSTR && n>=data_column) break;
		n++;
	}
	ncols = n-1;
	ASSERT(ncols>0);

	// Go back through the columns, and extract the header text
	if (titles) delete [] titles;
	titles = new CString[ncols];
	for (i=0; i<ncols; i++) {
		v = xl.GetValue(1,i+1);
		if (V_VT(&v)==VT_BSTR) titles[i] = V_BSTR(&v);
	}

	// Find flaw name/column
	if (flaw_column) flaw_name = titles[flaw_column-1];
	else {
		for (i=1; i<data_column; i++) {
			if (flaw_name.CompareNoCase(titles[i-1])==0) flaw_column = i;
		}
	}
	if (!flaw_column) {
		str = "No column labeled \"";
		str += flaw_name + "\"";
		AfxMessageBox(str);
		return FALSE;
	}
	if (flaw_column >= data_column) {
		str = "Data columns must start to right of flaw column";
		AfxMessageBox(str);
		return FALSE;
	}

	// Count rows
	for (j=2; j>0; j++) {
		v = xl.GetValue(j,flaw_column);
		if (V_VT(&v)==VT_EMPTY) break;
	}
	nrows = j-2;
	if (!nrows) {
		AfxMessageBox("No entries found on flaw column of Data worksheet");
		return FALSE;
	}
	nsets = ncols-data_column+1;

	if (nsets<=0) {
		AfxMessageBox("No alphanumeric entries (titles) found for inspections on first row of Data worksheet");
		return FALSE;
	}

	// Get the flaw data
	if (flaws) delete [] flaws;
	flaws = new CrackData[nrows];
	CrackData *pflaw = flaws;
	for (i=0; i<nrows; i++, pflaw++) {
		pflaw->Init(nsets);
		pflaw->Parse(i+2,flaw_column,data_column);
	}

	// Transform crack size

	if (IsCustom())	xl.GetSheet("Info");
	pflaw = flaws;
	for (i=0; i<nrows; i++, pflaw++) {
		if (!pflaw->bValid) continue;
		pflaw->crkf = a_fwd(pflaw->crksize);
	}
	return TRUE;
}



BOOL CPodDoc::HaveData()
{
	if (xl.GetWorkbookCount()<=0) return FALSE;
	return nrows>0 && nsets>0;
}

/*
*
*/
void CPodDoc::GetCensorCounts(int counts[8])
{
	int i, idx;
	for (i=0; i<8; i++) counts[i] = 0;
	for (i=0; i<nrows; i++) {
		if (!flaws[i].IsIncluded()) continue;
		idx = flaws[i].ncensor;
		counts[idx]++;
	}
	ASSERT(counts[1]==acount && counts[2]==bcount);
	ASSERT(counts[0]+counts[3]+counts[4]==npts);
}


/*
*  Look for minimum/maximum crack size (after censoring)
*/

void CPodDoc::GetCrackRange()
{
	int i;
	double crksize;
	CrackData *pflaw;
	BOOL first = TRUE;
	if (!nrows) return;

	// Find minimum/maximum crack sizes
	for (i=0; i<nrows; i++) {
		if (!flaws[i].IsIncluded()) continue;
		crksize = flaws[i].crksize;
		if (first) {
			crkmin = crkmax = crksize;
			first = FALSE;
		}
		else {
			if (crksize<crkmin) crkmin = crksize;
			else if (crksize>crkmax) crkmax = crksize;
		}
	}

	// look for minimum/maximum values for cracks where inspections are used

	first = TRUE;
	pflaw = flaws;
	for (i=0; i<nrows; i++, pflaw++) {
		if (!pflaw->IsIncluded()) continue;
		if (!pflaw->count) continue;
		crksize = pflaw->crksize;
		if (first) {
			xmin = xmax = crksize;
			first = FALSE;
		}
		else {
			if (crksize<xmin) xmin = crksize;
			else if (crksize>xmax) xmax = crksize;
		}
	}

	// set amax (for plots)
	CInfo *pinfo;
	amax = crkmax;
	pinfo = GetInfo("Amax:");
	if (pinfo) {
		if (pinfo->IsNumber()) amax = pinfo->value();
	}
}


int CPodDoc::CountInsp(int set)
{
	int i, count = 0;
	CrackData *pflaw = flaws;
	if (set<0 || set>=nsets) return 0;
	for (i=0; i<nrows; i++, pflaw++) {
		if (!pflaw->IsIncluded()) continue;
		if (pflaw->rdata[set].IsIncluded()) count++;
	}
	return count;
}

int compare(const void *elem1, const void *elem2)
{
	CrackData *pd1 = (CrackData *)elem1;
	CrackData *pd2 = (CrackData *)elem2;
	if (pd1->bValid && pd2->bValid) {
		if (pd1->crksize<pd2->crksize) return -1;
		if (pd1->crksize>pd2->crksize) return 1;
		return 0;
	}
	if (pd1->bValid && !pd2->bValid) return -1;
	if (!pd1->bValid && pd2->bValid) return 1;
	return 0;
}


void CPodDoc::SortData()
{
	qsort(flaws);
}
