// podDoc.cpp : implementation of the CPodDoc class
//

#include "stdafx.h"
#include "pod.h"

#include "podDoc.h"
#include "XlControl.h"
#include "XlRoutines.h"
#include "InfoDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// defined in AhatCharts.cpp
BOOL HaveChart(const CString &name);

// defined in funcr
bool IsCustom();

extern const CString POD_Version, POD_Build;

const CString POD_Version = " POD 3.0";
const CString POD_Build = "3/6/01";

/////////////////////////////////////////////////////////////////////////////
// CPodDoc

IMPLEMENT_DYNCREATE(CPodDoc, CDocument)

BEGIN_MESSAGE_MAP(CPodDoc, CDocument)
	//{{AFX_MSG_MAP(CPodDoc)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_TASKS_RECALCULATE, OnAnalysis)
	ON_UPDATE_COMMAND_UI(ID_TASKS_RECALCULATE, OnUpdateTasksRecalculate)
	ON_COMMAND(ID_TASKS_SORTBYSIZE, OnTasksSortbysize)
	ON_UPDATE_COMMAND_UI(ID_TASKS_SORTBYSIZE, OnUpdateTasksSortbysize)
	ON_COMMAND(ID_CHART_2, OnChart2)
	ON_UPDATE_COMMAND_UI(ID_CHART_2, OnUpdateChart2)
	ON_COMMAND(ID_CHART_1, OnChart1)
	ON_UPDATE_COMMAND_UI(ID_CHART_1, OnUpdateChart1)
	ON_COMMAND(ID_CHART_3, OnChart3)
	ON_UPDATE_COMMAND_UI(ID_CHART_3, OnUpdateChart3)
	ON_COMMAND(ID_CHART_4, OnChart4)
	ON_UPDATE_COMMAND_UI(ID_CHART_4, OnUpdateChart4)
	ON_COMMAND(ID_CHART_5, OnChart5)
	ON_UPDATE_COMMAND_UI(ID_CHART_5, OnUpdateChart5)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BEGIN_DISPATCH_MAP(CPodDoc, CDocument)
	//{{AFX_DISPATCH_MAP(CPodDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//      DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_DISPATCH_MAP
END_DISPATCH_MAP()

// Note: we add support for IID_IPod to support typesafe binding
//  from VBA.  This IID must match the GUID that is attached to the 
//  dispinterface in the .ODL file.

// {7AA5EB65-C35B-11D2-BE9F-444553540000}
static const IID IID_IPod =
{ 0x7aa5eb65, 0xc35b, 0x11d2, { 0xbe, 0x9f, 0x44, 0x45, 0x53, 0x54, 0x0, 0x0 } };

BEGIN_INTERFACE_MAP(CPodDoc, CDocument)
	INTERFACE_PART(CPodDoc, IID_IPod, Dispatch)
END_INTERFACE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPodDoc construction/destruction

CPodDoc::CPodDoc()
{
	titles = 0;
	flaws = 0;
	rlonx = 0;
	rlony = 0;
	nrows = npts = 0;
	pfdata = 0;

	// Optional parameters which are not passed 
	// can be passed a VARIANT containing VT_ERROR/DISP_E_PARAMNOTFOUND.
    V_VT(&vNotPassed) = VT_ERROR;
    V_ERROR(&vNotPassed) = DISP_E_PARAMNOTFOUND;

    V_VT(&vTrue) = VT_BOOL;
	V_I4(&vTrue) = (int) TRUE;

	V_VT(&vFalse) = VT_BOOL;
	V_I4(&vFalse) = (int) FALSE;

	EnableAutomation();

	AfxOleLockApp();
}

CPodDoc::~CPodDoc()
{
	delete [] titles;
	delete [] flaws;
	delete [] rlonx;
	delete [] rlony;
	delete [] pfdata;

	AfxOleUnlockApp();
}

BOOL CPodDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

BOOL CPodDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	if (IsModified())
		TRACE0("Warning: OnOpenDocument replaces an unsaved document.\n");


	DeleteContents();
	SetModifiedFlag();  // dirty during de-serialize

	TRY
	{
		XlOpen(lpszPathName);
		OnAnalysis();
	}
	CATCH_ALL(e)
	{
		e->ReportError();
		DeleteContents();   // remove failed contents
		return FALSE;
	}
	END_CATCH_ALL

	SetModifiedFlag(FALSE);     // start off with unmodified

	return TRUE;
}

BOOL CPodDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	xl.SaveAs(lpszPathName);
	return TRUE;
}

BOOL CPodDoc::XlOpen(CString filepath)
{
	if (!xlReady()) return FALSE;
	xl.Open(filepath);
	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPodDoc diagnostics

#ifdef _DEBUG
void CPodDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPodDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPodDoc commands

void CPodDoc::OnFileSave() 
{
	CWaitCursor wait;
	xl.Save();
}

void CPodDoc::DeleteContents() 
{
	xl.Close(0,FALSE);
	nrows = 0;
}

// defined in import.cpp
int ImportData(char const *filename, int analysis);

void CPodDoc::OnFileImport() 
{
	static char BASED_CODE filter[] = 
		"Ahat Data Files (*.hat)|*.hat|Pass/Fail Files (*.pf)|*.pf|All Files (*.*)|*.*||";

	// Show File dialog
	CFileDialog opendialog( TRUE, 0, 0, OFN_FILEMUSTEXIST, filter, AfxGetMainWnd() );
	if ( opendialog.DoModal() == IDOK )
	{
		CWaitCursor wait;
		CString filename = opendialog.GetPathName();
		xl.CreateWorkbook();
		if (xlGetSheet("Sheet1")) xl.worksheet.SetName("Info");
		CString ext = opendialog.GetFileExt();
		analysis = 0;
		if (ext.CompareNoCase("HAT")==0) analysis = AHAT_ANALYSIS;
		else if (ext.CompareNoCase("PF")==0) analysis = PF_ANALYSIS;
		ImportData((char const *)filename,analysis);
		OnAnalysis();
		SetModifiedFlag(TRUE);
		UpdateAllViews(NULL);
	}
}

void CPodDoc::OnFileNew()
{
	Worksheets worksheets;
	int count;
	if (xl.GetWorkbookCount()!=0) return;
	try {
		xl.CreateWorkbook();
		worksheets = xl.workbook.GetWorksheets();
		count = worksheets.GetCount();
		if (count) {
			xl.worksheet = worksheets.GetItem(COleVariant((short)1));
			xl.worksheet.SetName("Data");
			AfxMessageBox("Enter your data into the data sheet,\nthen recalculate.");
		}
	}
	catch(COleException *e)
	{
		e->ReportError();
	}
}

void CPodDoc::OnAnalysis() 
{
	int iret, n;
	VARIANT vDispatch;
	V_VT(&vDispatch) = VT_DISPATCH;
	CWaitCursor wait;
	// Check for existence of data sheet
	if (!xlGetSheet("Data")) {
		n = xl.GetWorksheetCount();
		switch (n) {
		case 0:
			return;
		case 1:
			iret = AfxMessageBox("Make the current worksheet the Data sheet?",
				MB_ICONQUESTION|MB_OKCANCEL);
			if (iret!=IDOK) return;
			xl.GetSheet(n);
			xl.worksheet.SetName("Data");
			break;
		default:
			AfxMessageBox("No Excel worksheet called \"Data\"");
			return;
		}
	}
	_Worksheet data_sheet = xl.worksheet;
	if (!xlGetSheet("Info")) {
		CInfoDialog dlg;
		if (dlg.DoModal()!=IDOK) return;
		xlGetEmptySheet("Info");
		xlSetColumnWidth(1,13);
		// Move info sheet before data sheet
		V_DISPATCH(&vDispatch) = data_sheet;
		xl.worksheet.Move(vDispatch,vNotPassed);
		dlg.WriteInfo();
		SetModifiedFlag(TRUE);
	}
	if (!GetInfo()) return;    //Info.cpp
	if (!ParseInfo()) return;  //Info.cpp
	if (!GetData()) return;    //CrackData.cpp
	if (IsCustom()) xlGetSheet("Info");
	if (analysis==AHAT_ANALYSIS) {
		ahat_censor();              //defined in ahat.cpp
		GetCrackRange();            //defined in CrackData.cpp
		ShowInfo();                 //defined in Info.cpp
		if (model==NONLINEAR_MODEL) ahat_nonlinear_solve();
		else ahat_solve();          //defined in ahat.cpp
		ahat_residuals();
		ahat_print();
		if (HaveChart("Ahat vs. a")) AhatChart();
		if (HaveChart("FitPlot")) FitChart();
		if (HaveChart("Residuals Plot")) ResidualsChart();
		if (HaveChart("Threshold Plot")) {
			ahat_decision();
			ThresholdChart();
		}
		if (HaveChart("POD")) {
			ahat_pod();
			PODChart();
		}
	}
	else if (analysis==PF_ANALYSIS) {
		pf_censor();
		GetCrackRange();
		ShowInfo();
		if (!pf_solve()) return;
		pf_residuals();
		pf_print();
		if (HaveChart("FitPlot")) FitChart();
		if (HaveChart("Residuals Plot")) ResidualsChart();
		if (HaveChart("POD")) {
			pf_pod();
			PODChart();
		}
	}

	// Move results sheet after data sheet
	if (xlGetSheet("Results")) {
		V_DISPATCH(&vDispatch) = data_sheet;
		xl.worksheet.Move(vNotPassed,vDispatch);
	}
}

void CPodDoc::OnUpdateTasksRecalculate(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(xl.GetWorkbookCount()>0);
	
}

enum XlSortOrder {
    xlAscending = 1,
    xlDescending = 2
} XlSortOrder;
typedef enum {
    xlSortRows = 2,
    xlSortColumns = 1
} XlSortOrientation;
typedef enum {
    xlGuess = 0,
    xlNo = 2,
    xlYes = 1
} XlYesNoGuess;

void CPodDoc::OnTasksSortbysize() 
{
	// Get Data worksheet
	if (xl.GetWorkbookCount()<=0) return;
	if (!xl.GetSheet("Data")) {
		AfxMessageBox("No Excel worksheet called \"Data\"");
		return;
	}
	CString str = "A1:"+xlCell(nrows+1,ncols);
	TRACE("Sort range: %s\n",(char const *)str);
	Range range = xl.GetRange(str);

	Range key = xl.GetRange(1,flaw_column);
	VARIANT vKey;
	V_VT(&vKey) = VT_DISPATCH;
	V_DISPATCH(&vKey) = key;

	TRY {
	range.Sort(
		vKey, // Key1
		xlAscending, // long Order1
		vNotPassed, // Key2
		vNotPassed, // Type
		xlAscending, // long Order2
		vNotPassed, // Key3
		xlAscending, // long Order3
		xlYes, // long Header
		vNotPassed, // OrderCustom
		vNotPassed, // MatchCase
		xlSortColumns, // long Orientation
		0, // long SortMethod
		vNotPassed, // IgnoreControlCharacters
		vNotPassed, // IgnoreDiacritics
		vNotPassed  // IgnoreKashida
	);
	}
	CATCH(COleException, e)
	{
		e->ReportError();
	}
	END_CATCH
		
	
}

void CPodDoc::OnUpdateTasksSortbysize(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(HaveData());	
}

void CPodDoc::OnChart1() 
{
	AhatChart();
	
}

void CPodDoc::OnUpdateChart1(CCmdUI* pCmdUI) 
{
	if (HaveData() && analysis==AHAT_ANALYSIS) {
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(HaveChart("Ahat vs. a")?1:0);
	}
	else {
		pCmdUI->Enable(FALSE);
		pCmdUI->SetCheck(0);
	}
}

void CPodDoc::OnChart2() 
{
	FitChart();
}

void CPodDoc::OnUpdateChart2(CCmdUI* pCmdUI) 
{
	if (HaveData()) {
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(HaveChart("FitPlot")?1:0);
	}
	else {
		pCmdUI->Enable(FALSE);
		pCmdUI->SetCheck(0);
	}
}

void CPodDoc::OnChart3() 
{
	ResidualsChart();
	
}

void CPodDoc::OnUpdateChart3(CCmdUI* pCmdUI) 
{
	if (HaveData() && analysis==AHAT_ANALYSIS) {
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(HaveChart("Residuals Plot")?1:0);
	}
	else {
		pCmdUI->Enable(FALSE);
		pCmdUI->SetCheck(0);
	}
}

void CPodDoc::OnChart4() 
{
	ahat_decision();
	ThresholdChart();
}

void CPodDoc::OnUpdateChart4(CCmdUI* pCmdUI) 
{
	if (HaveData() && analysis==AHAT_ANALYSIS && nath>1) {
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(HaveChart("Threshold Plot")?1:0);
	}
	else {
		pCmdUI->Enable(FALSE);
		pCmdUI->SetCheck(0);
	}
}

void CPodDoc::OnChart5() 
{
	if (analysis==AHAT_ANALYSIS) ahat_pod();
	else if (analysis==PF_ANALYSIS) pf_pod();
	else return;
	PODChart();
	
}

void CPodDoc::OnUpdateChart5(CCmdUI* pCmdUI) 
{
	if (HaveData()) {
		pCmdUI->Enable(TRUE);
		pCmdUI->SetCheck(HaveChart("POD")?1:0);
	}
	else {
		pCmdUI->Enable(FALSE);
		pCmdUI->SetCheck(0);
	}
}
