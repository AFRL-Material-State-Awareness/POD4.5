/* ahat.cpp
*
*/
#include "stdafx.h"
#include <math.h>
#include <search.h>
#include "PodDoc.h"
#include "XlControl.h"
#include "excel8.h"
#include "linreg.h"
#include "matrix.h"

CString funcstr(CString v, int iopt);
bool IsCustom();
CString a_str();
CString r_str();
double a_fwd(double v);
double a_inv(double v);
double r_fwd(double v);
double r_inv(double v);

// defined in alogam.cpp
double alogam(double x);

// defined in betain.cpp
double betain(double x, double p, double q, double beta);

// defined in phinv.cpp
double phinv(double p);

// defined in Info.cpp
void PutValue(int row, int col, double value);

// defined in mdnord.cpp
double mdnord(double x);

double leqslv(CMatrix &rj, double *dd);

// defined in smtxinv.cpp
double smtxinv(CMatrix &x, CMatrix &xi);

// defined in sysolv.cpp
int ahat_sysolv(double *x, CMatrix &jb, double *fnorm);

// defined in nonlinear.cpp
int ahat_nonlinear_sysolv(double *x, CMatrix &jb, double *fnorm);

extern CPodDoc *pDoc;

// AHAT parameters

int ahat_model;
CMatrix var(3,3);
CMatrix var4(4,4);
double parm[4];

double scnt, ssy;
double sw;
int npts2;

class CAnal
{
public:
	void Init(CrackData *flaw);
	void write(int row, int col);
	double crksize;
	double crkf;
	double ybar;
	double ybar_inv;
	double yfit;
	double yfit_inv;
	double diff;
	double dstar;
};

CAnal *anal = 0;

void CPodDoc::ahat_censor()
{
	int i;
	CrackData *pdata;

	ahat_model = model;
	if (rlonx) delete [] rlonx;
	if (rlony) delete [] rlony;
	rlonx = new double[nrows];
	rlony = new double[nrows];

	SortData();

	pdata = flaws;
	ssy = scnt = 0.0;
	npts = acount = bcount = 0;
	for (i=0; i<nrows; i++, pdata++) {
		pdata->ahat_censor(tmin,tmax);
		if (!pdata->IsIncluded() || !pdata->count) continue;
		switch (pdata->ncensor) {
		case 0:
		case 3:
		case 4:
			rlonx[npts] = pdata->crkf;
			rlony[npts] = pdata->ybar;
			npts++;
			scnt += pdata->scnt;
			ssy += pdata->ssy;
			break;
		case 1:
			acount++;
			break;
		case 2:
			bcount++;
			break;
		}
	}
	sw = sqrt(ssy/scnt);

	npts2 = npts;

	// Append censored cracks above threshold
	if (acount) {
		pdata = flaws;
		for (i=0; i<nrows; i++, pdata++) {
			if (!pdata->IsIncluded()) continue;
			if (pdata->ncensor!=1) continue;
			rlonx[npts2] = pdata->crkf;
			rlony[npts2] = pdata->ybar;
			npts2++;
		}
	}

	// Append censored cracks below threshold
	if (bcount) {
		pdata = flaws;
		for (i=0; i<nrows; i++, pdata++) {
			if (!pdata->IsIncluded()) continue;
			if (pdata->ncensor!=2) continue;
			rlonx[npts2] = pdata->crkf;
			rlony[npts2] = pdata->ybar;
			npts2++;
		}
	}

	ASSERT(npts2 == npts+acount+bcount);
}

/*
C
C   Perform 1st pass:
C     1st pass - all data are used including values with censored y's
C
C   If 1st pass doesn't converge:
C     2nd pass - second set of initial guesses is generated using
C                only uncensored values
C
C   If 2nd pass doesn't converge:
C     3rd pass - user is given the chance to select initial guesses
C       
*/
int CPodDoc::ahat_solve()
{
	int iret;
	double fnorm;
	linear_regression lr;

	pDoc = this;

	// first pass - 
	// generate initial guess using all data, including values with censored y's
	lr.regress(rlonx,rlony,npts2);  
	parm[0] = lr.intercept;
	parm[1] = lr.slope;
	parm[2] = lr.rms;
	iret = ahat_sysolv(parm, var, &fnorm);
	if (!iret) return 0;
	TRACE("Pass 1 Ahat analysis error return %d\n",iret);

	// second pass
	// generate initial guess using only uncensored values
	lr.regress(rlonx,rlony,npts);
	parm[0] = lr.intercept;
	parm[1] = lr.slope;
	parm[2] = lr.rms;
	iret = ahat_sysolv(parm, var, &fnorm);
	if (!iret) return 0;

	TRACE("Pass 2 Ahat analysis error return %d\n",iret);
	return -1;
}

int CPodDoc::ahat_nonlinear_solve()
{
	int iret;
	double fnorm;
	linear_regression lr;

	pDoc = this;

	// first pass - 
	// generate initial guess using all data, including values with censored y's
	lr.regress(rlonx,rlony,npts2);
	parm[0] = lr.intercept;
	parm[1] = lr.slope;
	parm[2] = lr.rms;
	parm[3] = 0.0;
	iret = ahat_nonlinear_sysolv(parm, var4, &fnorm);
	if (!iret) return 0;
	TRACE("Pass 1 Ahat analysis error return %d\n",iret);

	// second pass
	// generate initial guess using only uncensored values
	lr.regress(rlonx,rlony,npts);
	parm[0] = lr.intercept;
	parm[1] = lr.slope;
	parm[3] = 0.0;
	parm[2] = lr.rms;
	iret = ahat_nonlinear_sysolv(parm, var4, &fnorm);
	if (!iret) return 0;

	TRACE("Pass 2 Ahat analysis error return %d\n",iret);
	return -1;
}

int compare1(const void *elem1, const void *elem2);
int compare2(const void *elem1, const void *elem2);

void CPodDoc::ahat_residuals()
{
	int i, j, row, col, n;
	CrackData *pdata;
	Range range;
	Interior interior;

	if (IsCustom()) xlGetSheet("Info");

	// Calculate extremes of fit
	double x1, y1, x2, y2;
	double tlimit;
	x1 = a_fwd(xmin);
	y1 = parm[0]+parm[1]*x1;
	tlimit = r_inv(y1);
	if (tlimit<tmin) {
		y1 = r_fwd(tmin);
		x1 = (y1-parm[0])/parm[1];
	}
	if (tmax>tmin) {
		if (tlimit>tmax) {
			y1 = r_fwd(tmax);
			x1 = (y1-parm[0])/parm[1];
		}
	}
	x2 = a_fwd(xmax);
	y2 = parm[0]+parm[1]*x2;
	tlimit = r_inv(y2);
	if (tlimit<tmin) {
		y2 = r_fwd(tmin);
		x2 = (y2-parm[0])/parm[1];
	}
	if (tmax>tmin) {
		if (tlimit>tmax) {
			y2 = r_fwd(tmax);
			x2 = (y2-parm[0])/parm[1];
		}
	}

	extern int a_opt, r_opt;
	if (a_opt<=XF_LOG) {
		x1 = a_inv(x1);
		x2 = a_inv(x2);
	}
	if (r_opt<=XF_LOG) {
		y1 = r_inv(y1);
		y2 = r_inv(y2);
	}


	if (anal) delete [] anal;
	anal = new CAnal[npts];

	pdata = flaws;
	for (i=n=0; i<nrows; i++, pdata++) {
		if (!pdata->IsIncluded() || !pdata->count) continue;
		switch (pdata->ncensor) {
		case 0:
		case 3:
		case 4:
			anal[n].Init(pdata);
			n++;
		}
	}
	ASSERT(n==npts);


	// calculate fitted ahat
	double x, y;
	row = 2;
	pdata=flaws;
	for (j=0; j<nrows; j++, pdata++) {
		if (!pdata->bValid) continue;
		x = pdata->crkf;
		y = parm[0] + parm[1]*x;
		if (model==NONLINEAR_MODEL) y /= (1.0+parm[3]*x);
		pdata->yfit = y;
		pdata->yfit_inv = r_inv(y);
	}

	
	xlGetEmptySheet("Residuals");
	row = 1;
	xlValue(row,1,"a");
	xlValue(row,3,"ahat");
	CString msg;
	msg = a_str();
	xlValue(row,2,msg);
	msg = r_str();
	xlValue(row,4,msg);
	xlValue(row,5,"fit"); xlValue(row,6,"diff");

	for (i=0; i<npts; i++) {
		anal[i].write(i+2,1);
	}

	// add points that have been totally censored
	pdata = flaws;
	row = npts+3;
	for (i=n=0; i<nrows; i++, pdata++) {
		if (!pdata->IsIncluded() || !pdata->count) continue;
		switch (pdata->ncensor) {
		case 1:
		case 2:
			pdata->ahat_write(row++,1);
			n++;
		}
	}
	ASSERT(n==acount+bcount);
	if (n) row++;

	// add points that have been excluded from analysis
	pdata = flaws;
	nexcluded = 0;
	for (i=0; i<nrows; i++, pdata++) {
		if (pdata->IsIncluded() || !pdata->count) continue;
		if (!pdata->IsNumber()) continue;
		pdata->ahat_write(row++,1);
		nexcluded++;
	}


	// write threshold and saturation levels for chart
	xlValue(1,7,"a");  xlValue(1,8,"sig. min");  xlValue(1,9,"sig. max");
	xlValue(2,7,crkmin); xlValue(2,8,tmin); xlValue(2,9,tmax);
	xlValue(3,7,crkmax); xlValue(3,8,tmin); xlValue(3,9,tmax);

	// write extremes of fit for chart
	xlValue(5,7,"a");
	xlValue(5,8,"ahat");
	xlValue(6,7,x1);
	xlValue(6,8,y1);
	xlValue(7,7,x2);
	xlValue(7,8,y2);


	COleVariant v;
	xlValue(1,11,"a"); xlValue(1,12,"fit");
	for (i=0; i<nsets; i++) xlValue(1,13+i,titles[i+data_column-1]);
	row = 2;
	pdata=flaws;
	for (j=0; j<nrows; j++, pdata++) {
		if (!pdata->bValid) continue;
		x = pdata->crksize;
		xlValue(row,11,x);
		v = pdata->ColorIndex;
		if (V_I4(&v) != xlNone) {
			range = xl.GetRange(row,11);
			interior = range.GetInterior();
			interior.SetColorIndex(v);
		}
		x = pdata->crkf;
		y = pdata->yfit_inv;
		if (y<tmin) y = tmin;
		else if (y>tmax && tmax>tmin) y=tmax;
		else xlValue(row,12,y);
		for (i=0; i<nsets; i++) {
			col = 13+i;
			v = pdata->rdata[i].v;
			if (V_VT(&v)==VT_R8) {
				y = V_R8(&v);
				if (y<tmin) y = tmin;
				if (y>tmax && tmax>tmin) y = tmax;
				xlValue(row,col,y);
			}
			v = pdata->rdata[i].ColorIndex;
			if (V_I4(&v) != xlNone){
				range = xl.GetRange(row,col);
				interior = range.GetInterior();
				interior.SetColorIndex(v);
			}
		}
		row++;
	}
}

static char const * choices[] = {
	"P > 0.1", "0.05 < P <= 0.1", ".025 < P <= 0.05",
    "0.01 < P <= .025", ".005 < P <= 0.01", "P <= .005"
};

char const *probrng(double value)
{
	double ranges[] = {
		0.1, 0.05, 0.025, 0.01, 0.005
	};
	int i;
	int n = sizeof(ranges) / sizeof(ranges[0]);
	for (i=0; i<n; i++) {
		if (value > ranges[i]) return choices[i];
	}
	return choices[n];
}


char const *rngfindr(double value)
{
	double ranges[] = {
		0.631, 0.752, 0.873, 1.035, 1.159
	};
	int i, n = 5;
	for (i=0; i<n; i++) {
		if (value <= ranges[i]) return choices[i];
	}
	return choices[n];
}

// defined in alnorm.cpp
double alnorm(double x, boolean upper);

// defined in gammds.cpp
double gammds(double y, double p);

void CPodDoc::ahat_tests()
{
	int i, j, n;

	///////////////////////////////////////////////////////////////////////
	// Test of normality
	double lim;
	double asq, astar;
	double tmp1, tmp2, tmp3, tmp4;

	// sort table by deviation
	qsort(anal,npts,sizeof(CAnal),compare1);

	lim = (double) npts;
	asq = 0.0;
	for (i=0; i<npts; i++) {
		tmp1 = (double)(2*i+1);
		tmp2 = log(anal[i].dstar);
		tmp3 = log(1.0-anal[npts-1-i].dstar);
		tmp4 = (tmp1*(tmp2+tmp3))/lim;
		asq += tmp4;
	}
	asq = -(asq+lim);

	astar = asq * (1.0 + (0.75/lim) + (2.25 / (lim*lim)));

	xlValue(data_row,1,"Normality: Anderson-Darling");
	xlValue(data_row,4,"A* = ");
	xlHAlign(data_row,4,xlRight);
	PutValue(data_row,5,astar);
	xlValue(data_row,6,rngfindr(astar));
	data_row++;

	////////////////////////////////////////////////////////////////////////
	// Homogenity of Variance
	const int ngrps = 2;
	int cnts[ngrps];
	double avg[ngrps],sum[ngrps],vor[ngrps];
	double av, sv, diff;
	int cnt, intrvl;

	// Sort data by crack size
	qsort(anal,npts,sizeof(CAnal),compare2);

	// Divide the data into groups
	intrvl = npts/ngrps;
	for (i=0; i<ngrps; i++) cnts[i] = intrvl;
	// If groups can not be equal sizes, add 1 to first few groups
	n = npts - ngrps*intrvl;
	for (i=0; i<n; i++) cnts[i]++;

	// Calculate variance of residuals in each group
	// "i" is the group index; "j" indexes the values within the group
	n=0;
	for (i=0; i<ngrps; i++) {
		av = sv = 0.0;
		cnt = cnts[i];
		for (j=0; j<cnt; j++) av += anal[n+j].diff;
		av /= cnt;
		for (j=0; j<cnt; j++) {
			diff = anal[n+j].diff-av;
			sv += diff*diff;
		}
		avg[i] = av;
		sum[i] = sv;
		vor[i] = sv/(cnt-1.0);
		n += cnt;
	}
	double term1, term2, term3, term4, dof, grpcnt;
	term1 = term2 = term3 = term4 = 0.0;
	dof = (double)(ngrps-1);
	grpcnt = (double)(ngrps);
	for (i=0; i<ngrps; i++) {
		cnt = cnts[i];
		term1 += cnt;
		term2 += 1.0/(cnt-1);
		term3 += (cnt-1)*log(vor[i]);
		term4 += (cnt-1)*vor[i];
	}
	term1 -= grpcnt;
	term4 /= term1;
	double bd, halfbd, halfdof, p;
	bd = (term1*log(term4)-term3)/(1.0+((term2-(1.0/term1))/(3.0*dof)));
	halfbd = 0.5*bd;
	halfdof = 0.5*dof;

	// Calculate Equal-Variance Bartlet
	p = 1.0 - gammds(halfbd, halfdof);

	TRACE("Equal Variance:  Barlett P = %g B = %g\n",p,bd);

	Range range;
	Characters chars;
	Font font;

	xlValue(data_row,1,"Equal Variance: Bartlett");
	xlValue(data_row,4,"c2 = ");
	range = xl.GetRange(data_row,4);
	range.SetHorizontalAlignment(COleVariant((long)xlRight));
	chars = range.GetCharacters(COleVariant((long)1),COleVariant((long)1));
	font = chars.GetFont();
	font.SetName(COleVariant("Symbol"));
	chars = range.GetCharacters(COleVariant((long)2),COleVariant((long)1));
	font = chars.GetFont();
	font.SetSuperscript(vTrue);
	PutValue(data_row,5,bd);
	xlValue(data_row,6,probrng(p));
	data_row++;

	/////////////////////////////////////////////////////////////////////////////
	//  Test of linearity

	CString msg;
	double crksize;
	double totss, pess;
	double pedf; // pure error degrees of freedom
	double lofss;
	double lofdf;
	double beta, fcalc, paff, x;

	// check for duplicates

	int nbrsets = 0;  // # sets of unique crack sizes

	for (i=0; i<npts; ) {
		crksize = anal[i].crksize;
		nbrsets++;
		i++;
		while (i<npts && anal[i].crksize==crksize) i++;
	}
	if (nbrsets==npts) goto done;  // linearity test can not be performed

	// Determine total variance
	totss = 0.0;
	for (i=0; i<npts; i++) {
		diff = anal[i].diff;
		totss += diff*diff;
	}

	// process duplicates
	pess = 0.0;
	for (i=0; i<npts; ) {
		crksize = anal[i].crksize;
		diff = anal[i].diff;
		term1 = diff*diff;
		term2 = diff;
		n=1;
		i++;
		while (i<npts && anal[i].crksize==crksize) {
			diff = anal[i++].diff;
			term1 += diff*diff;
			term2 += diff;
			n++;
		}
		term2 = (term2*term2)/n;
		pess += (term1-term2);
	}

	// LOF means "lack of fit"
	// PE  means "pure error"
	// LOFDF = RegressionDF - PureErrorDF
	pedf = (double)(npts-nbrsets);
	lofss = totss - pess;
	lofdf = (npts-2) - pedf;

	// Linearity results
	beta = alogam(lofdf/2.0) + alogam(pedf/2.0) - alogam((lofdf+pedf)/2.0);
	fcalc = (lofss/lofdf) / (pess/pedf);
	x = pedf / (pedf + (lofdf*fcalc));
	paff = betain(x,pedf/2.0,lofdf/2.0,beta);
	TRACE("Linearity test: fcalc %g paff %g\n",fcalc,paff);

	msg.Format("Lack of fit: Pure Error (df=%d)",(int)pedf);
	xlValue(data_row,1,msg);
	//xlValue(data_row,1,"Lack of fit: Pure error");
	xlValue(data_row,4,"F = ");
	range = xl.GetRange(data_row,4);
	range.SetHorizontalAlignment(COleVariant((long)xlRight));
	PutValue(data_row,5,fcalc);
	xlValue(data_row,6,probrng(paff));
	data_row++;

done:
	delete [] anal;
	anal = 0;
}



void CPodDoc::ahat_print()
{
	int i;
	double se[3];
	CString ahat_conv, a_conv, str_model;
	extern const CString POD_Version, POD_Build;

	double deter = smtxinv(var,var);
	for (i=0; i<3; i++) se[i] = sqrt(-var[i][i])*parm[2];

	double mhat, muhat;
	if (IsCustom()) xlGetSheet("Info");
	muhat = (r_fwd(pod_threshold) - parm[0])/parm[1];

	Range range;
	xlGetSheet("Results");
	data_row = info_row+1;

	xlBoldText(data_row,1,"\"ahat vs. a\" Analysis");
	xlBoldText(data_row,4,"Version:");
	xlValue(data_row,5,POD_Version);
	xlValue(data_row,6,POD_Build);
	data_row += 2;

	// show model
	xlValue(data_row,1,"Model:");
	ahat_conv = r_str();
	a_conv = a_str();
	str_model = ahat_conv + " = B0 + B1*" + a_conv;
	if (model == NONLINEAR_MODEL) str_model += " + B2*" + a_conv + "*" + ahat_conv;
	xlValue(data_row,2,str_model);
	data_row += 2;

	xlValue(data_row,1,"Parameter");
	xlValue(data_row,3,"Estimate");
	xlValue(data_row,5,"Std. Error");
	xlHAlign(data_row,1,data_row,5,xlCenter);
	xlUnderline(data_row,1,data_row,5);
	data_row++;

	char *msgs[3] = {
		"Intercept (B0)", "Slope (B1)", "Residual Error"
	};
	for (i=0; i<3; i++) {
		xlValue(data_row,1,msgs[i]);
		PutValue(data_row,3,parm[i]);
		PutValue(data_row,5,se[i]);
		data_row++;
	}
	data_row++;

	xlValue(data_row,1,"Repeatability Error");
	PutValue(data_row++,3,sw);

	xlBoldText(++data_row,1,"Tests of Assumptions");
	data_row++;
	xlValue(data_row,6,"P, if true");
	CString str = xlCell(data_row,6)+":"+xlCell(data_row+4,7);
	range = xl.GetRange(str);
	range.SetHorizontalAlignment(COleVariant((long)xlCenterAcrossSelection));
	xlUnderline(data_row,6,data_row,7);
	data_row++;
	ahat_tests();

	// POD Model Parameters
	xlBoldText(++data_row,1,"POD Model Parameters");
	data_row += 2;

	double rn;
	int nstrn = 0;
	for (i=0; i<nsets; i++) {
		if (CountInsp(i)) nstrn++;
	}
	sighat = parm[2]/parm[1];
	if (nstrn>1) {
		rn = (double)(nstrn-1)/(double)(nstrn);
		sighat = sqrt(parm[2]*parm[2]+rn*sw*sw);
		for (i=0; i<3; i++) {
			var[i][2] *= parm[2]/sighat;
			var[2][i] = var[i][2];
		}
		var[2][2] *= parm[2]/sighat;
		if (scnt) var[2][2] += rn*rn*pow(sw,4)/(2.0*scnt);
		sighat = sighat/parm[1];
	}
	xlValue(data_row,1,"Sigma");
	PutValue(data_row,2,sighat);
	data_row += 2;

	int mdown = 0;
	int totnpts = npts + acount + bcount;
	double tmp, tstsig;
	double v2[3];
	double a90, m90;
	double a9095, m9095;
	double chi = cbound(totnpts); // 5.13822 + 2.09651 / totnpts;
	double zp = phinv(pod_level); // 1.282 = phinv(0.9);
	double xp = zp*sighat;

	xlValue(data_row,1,"Inspection"); xlHAlign(data_row,1,xlCenter);
	data_row++;
	xlValue(data_row,1,"Threshold");
	xlValue(data_row,2,"a50");
	xlValue(data_row,3,asize);
	xlValue(data_row,4,alevel);
	xlHAlign(data_row,1,data_row,4,xlCenter);
	xlUnderline(data_row,1,data_row,4);
	data_row++;

	tmp = parm[2]/parm[1];
	tmp *= tmp;
	v2[0] = -(var[0][0]+(2.0*var[0][1]+var[1][1]*muhat)*muhat)*tmp;
	v2[1] = -(sighat*(var[0][1]+muhat*var[1][1])-var[0][2]-muhat*var[1][2])*tmp;
	v2[2] = -(var[1][1]*sighat*sighat-2.0*sighat*var[1][2]+var[2][2])*tmp;
	deter = v2[0]*v2[2]-v2[1]*v2[1];
	tstsig = sighat*sighat/v2[2];
	a90 = muhat + xp;
	if (IsCustom()) xlGetSheet("Info");
	m90 = a_inv(a90);
	mhat = a_inv(muhat);
	if (IsCustom()) xlGetSheet("Results");
	PutValue(data_row,1,pod_threshold);
	PutValue(data_row,2,mhat);
	PutValue(data_row,3,m90);
	if (tstsig < chi) {
		mdown = 1;
		PutValue(data_row,4,0.0);
		xlValue(data_row,4,"*");
		xlHAlign(data_row,4,xlCenter);
	}
	else {
		a9095 = sighat*(v2[0]+(2.0*v2[1]+v2[2]*zp)*zp);
		a9095 = a90 + a9095/(sqrt(sighat*a9095/chi-deter)-v2[1]-v2[2]*zp);
		if (IsCustom()) xlGetSheet("Info");
		m9095 = a_inv(a9095);
		if (IsCustom()) xlGetSheet("Results");
		PutValue(data_row,4,m9095);
	}
	data_row++;

	if (mdown) {
		xlValue(data_row,1,"*   Inadequate fit to the POD model");
		data_row++;
	}
}

void CPodDoc::ahat_decision()
{
	int i, j, nsteps;
	int mdown = 0;
	int totnpts = npts + acount + bcount;
	int row = 1;
	double muhat;
	double deter, tmp, tstsig;
	double threshold, step;
	double v2[3];
	double a90, m90;
	double a9095, m9095;
	double chi = cbound(totnpts); // 5.13822 + 2.09651 / totnpts;
	double zp = phinv(pod_level);  // 1.282;
	double xp = zp*sighat;

	xlGetEmptySheet("Threshold Data");
	xlValue(row,1,"Threshold");
	xlValue(row,2,"a50");
	xlValue(row,3,asize);  // e.g. a90
	xlValue(row,4,alevel); // e.g. a90/95
	xlValue(row,6,"V11");
	xlValue(row,7,"V12");
	xlValue(row,8,"V22");
	xlHAlign(data_row,1,data_row,8,xlCenter);
	row++;

	for (i=0; i<nath; i++) {
		if (i+1<nath) {
			nsteps = 10;
			step = (ath[i+1]-ath[i])/nsteps;
		}
		else {
			nsteps = 1;
			step = 0.0;
		}
		for (j=0; j<nsteps; j++) {
			threshold = ath[i] + step*j;
			if (IsCustom()) xlGetSheet("Info");
			muhat = (r_fwd(threshold) - parm[0])/parm[1];
			tmp = parm[2]/parm[1];
			tmp *= tmp;
			v2[0] = -(var[0][0]+(2.0*var[0][1]+var[1][1]*muhat)*muhat)*tmp;
			v2[1] = -(sighat*(var[0][1]+muhat*var[1][1])-var[0][2]-muhat*var[1][2])*tmp;
			v2[2] = -(var[1][1]*sighat*sighat-2.0*sighat*var[1][2]+var[2][2])*tmp;
			deter = v2[0]*v2[2]-v2[1]*v2[1];
			tstsig = sighat*sighat/v2[2];
			a90 = muhat + xp;
			m90 = a_inv(a90);
			tmp = a_inv(muhat);
			if (IsCustom()) xlGetSheet("Threshold Data");
			PutValue(row,1,threshold);
			PutValue(row,2,tmp);
			PutValue(row,3,m90);
			if (tstsig < chi) {
				mdown = 1;
				PutValue(row,4,0.0);
				xlValue(row,4,"*");
				xlHAlign(row,4,xlCenter);
			}
			else {
				a9095 = sighat*(v2[0]+(2.0*v2[1]+v2[2]*zp)*zp);
				a9095 = a90 + a9095/(sqrt(sighat*a9095/chi-deter)-v2[1]-v2[2]*zp);
				if (IsCustom()) xlGetSheet("Info");
				m9095 = a_inv(a9095);
				if (IsCustom()) xlGetSheet("Threshold Data");
				PutValue(row,4,m9095);
			}
			PutValue(row,6,v2[0]);
			PutValue(row,7,v2[1]);
			PutValue(row,8,v2[2]);
			row++;
		}
	}

	if (mdown) {
		xlValue(++row,1,"*   Inadequate fit to the POD model");
	}
}

void CPodDoc::ahat_pod()
{
	double tmp;
	double v[3];
	double deter;
	int totnpts = npts+acount+bcount;
	double chi = cbound(totnpts); // 5.13822 + 2.09651 / totnpts

	if (IsCustom()) xlGetSheet("Info");
	muhat = (r_fwd(pod_threshold) - parm[0])/parm[1];
	tmp = parm[2]/parm[1];
	tmp *= tmp;
	v[0] = -(var[0][0]+(2.0*var[0][1]+var[1][1]*muhat)*muhat)*tmp;
	v[1] = -(sighat*(var[0][1]+muhat*var[1][1])-var[0][2]-muhat*var[1][2])*tmp;
	v[2] = -(var[1][1]*sighat*sighat-2.0*sighat*var[1][2]+var[2][2])*tmp;
	deter = v[0]*v[2]-v[1]*v[1];
 
	int i, n, row;
	n = 75;
	double a, h, pod, pcl, zhat, zcl;
	double z[75];

	double abot = a_inv(muhat - 3.0*sighat);
	double atop = a_inv(muhat + 3.0*sighat);
	if (abot<0.0) abot = 0.0;
	if (amax<atop) atop = amax;
	double delta = (atop-abot)/(n-1);
	for (i=0; i<n; i++) {
		a = abot + delta*i;
		z[i] = (a_fwd(a)-muhat)/sighat;
	}


	xlGetEmptySheet("POD Data");
	xlValue(1,1,"a"); xlValue(1,2,"POD(a)");
	xlValue(1,3,clevel);
	for (i=0; i<n; i++) {
		a = abot + delta*i;
		zhat = z[i];
		h = chi*(v[0]+(v[2]*zhat+2.0*v[1])*zhat);
		zcl = (h>0.0? zhat - sqrt(h)/sighat: 0.0);
		pod = mdnord(zhat);
		pcl = mdnord(zcl);
		row = i+2;
		xlValue(row,1,a);
		xlValue(row,2,pod);
		xlValue(row,3,pcl);
	}
}

////////////////////////////////////////////////////////////////////////////////////
//  CrackData functions

void CrackData::ahat_write(int row, int col)
{
	// This assumes that ybar is log(ybar)
	xlValue(row,col++,crksize);
	xlValue(row,col++,crkf);
	xlValue(row,col++,ybar_inv);
	xlValue(row,col++,ybar);
}



////////////////////////////////////////////////////////////////////////////////////
//  CAnal functions


void CAnal::Init(CrackData *pdata)
{
	crksize = pdata->crksize;
	crkf = pdata->crkf;
	ybar = pdata->ybar;
	ybar_inv = pdata->ybar_inv;
	if (ahat_model == NONLINEAR_MODEL) {
		yfit = (parm[0]+parm[1]*crkf)/(1.0+parm[3]*crkf);
	}
	else {
		yfit = parm[0] + parm[1]*crkf;
	}
	diff = ybar - yfit;
	dstar = alnorm(diff/parm[2],false);
	yfit_inv = r_inv(yfit);
}


void CAnal::write(int row, int col)
{
	// This assumes that ybar is transformed
	xlValue(row,col++,crksize);
	xlValue(row,col++,crkf);
	xlValue(row,col++,ybar_inv);
	xlValue(row,col++,ybar);
	xlValue(row,col++,yfit);
	xlValue(row,col++,diff);
}

// Compare residuals

int compare1(const void *elem1, const void *elem2)
{
	CAnal *a1 = (CAnal *) elem1;
	CAnal *a2 = (CAnal *) elem2;
	double diff = a1->diff - a2->diff;
	if (diff<0.0) return -1;
	if (diff>0.0) return 1;
	return 0;
}

// Compare crack sizes

int compare2(const void *elem1, const void *elem2)
{
	CAnal *a1 = (CAnal *) elem1;
	CAnal *a2 = (CAnal *) elem2;
	double diff = a1->crksize - a2->crksize;
	if (diff<0.0) return -1;
	if (diff>0.0) return 1;
	return 0;
}
