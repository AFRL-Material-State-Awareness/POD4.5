/* Censor.cpp
*
*    ncensor = 0: some uncensored values
*              1: all censored above
*              2: all sensored below
*              3: some censored above
*              4: some censored below
*              5: censoring above and below
*              6: no values
*              7: error
*
*/
#include "stdafx.h"
#include <math.h>
#include "PodDoc.h"


// defined in funcr.cpp
double r_fwd(double v);
double r_inv(double v);



void CrackData::ahat_censor(double tmin, double tmax)
{
	int i, j, n;
	int acnt, bcnt;
	double value;
	acnt = bcnt = count = 0;
	ybar = 0.0;
	ncensor = 0;
	for (i=0; i<nsets; i++) {
		if (!rdata[i].IsIncluded()) {
			rdata[i].flag = IF_Missing;
			continue;
		}
		value = rdata[i].value();
		count++;
		if (value<=tmin) {
			bcnt++;
			rdata[i].flag = IF_Below;
		}
		else if (value>=tmax && tmax>tmin) {
			acnt++;
			rdata[i].flag = IF_Above;
		}
		else rdata[i].flag = IF_Okay;
	}
	/*
	*   If there are no inspection result values, set a flag and return
	*/
	if (count==0) {
		ncensor = 6;
		return;
	}
	/*
	* If there are inspection result values both above the saturation
	* and below the recording threshold for the same flaw, notify the
	* user and continue.
	*/
	if (acnt && bcnt) {
		ncensor = 5;
		return;
	}
	int cnt = acnt+bcnt;
	double rmin, rmax;
	rmin = r_fwd(tmin);
	rmax = r_fwd(tmax);

	/*
	* if all the inspection results were censored ...
	*/
	if (cnt==count) {
		if (acnt) {
			ybar = rmax;
			ybar_inv = tmax;
			ncensor = 1;
		}
		else if (bcnt) {
			ybar = rmin;
			ybar_inv = tmin;
			ncensor = 2;
		}
		return;
	}

	double r, ysum, ysqr;
	ysum = 0.0;
	ysqr = 0.0;
	for (j=n=0; j<nsets; j++) {
		if (rdata[j].flag!=IF_Okay) continue;
		r = r_fwd(rdata[j].value());
		ysum += r;
		ysqr += r*r;
		n++;
	}
	ybar = ysum/n;
	ybar_inv = r_inv(ybar);

	/*
	*  if no values have been censored ...
	*/
	if (!cnt) {
		scnt = (n==1? 1: (n-1));
		ssy = (ysqr - n*ybar*ybar);
		return;
	}

	/*
	*   if some are censored either above or below
	*/
	extern double phinv(double x);
	extern double nrmden(double x);
	double pstar, theta, thab, sigmar;
	double alpha, c;

	scnt = ssy = 0.0;
	if (acnt) {
		c = rmax;
		pstar = (double) acnt / (double) count;
		theta = phinv(pstar);
		thab = theta*(c-ybar);
		sigmar = (thab + sqrt(thab*thab + ((4.0/n)*(ysqr+(n*c-2.0*ysum)*c))))/2.0;
		alpha = count*nrmden(theta)/n;
		ybar += alpha*sigmar;
		ncensor = 3;
	}
	else if (bcnt) {
		CString msg;
		TRACE("row %d crack size %g ",data_row, crksize);
		c = rmin;
		pstar = (double) bcnt / (double) count;
		theta = phinv(pstar);
		thab = theta*(ybar-c);
		TRACE("pstar %g theta %g thab %g ",pstar,theta,thab);
		sigmar = (thab + sqrt(thab*thab + ((4.0/n)*(ysqr+(n*c-2.0*ysum)*c))))/2.0;
		alpha = count*nrmden(theta)/n;
		TRACE("sigmar %g alpha %g\n",sigmar,alpha);
		ybar -= alpha*sigmar;
		ncensor = 4;
	}
	else ncensor = 7; // should never be here (since cnt = acnt+bcnt is nonzero
	ybar_inv = r_inv(ybar);
}

void CrackData::pf_censor(double tmin)
{
	int i;
	count = above = 0;
	for (i=0; i<nsets; i++) {
		if (rdata[i].IsIncluded()) {
			count++;
			if (rdata[i].value()>tmin) above++;
			rdata[i].flag = IF_Okay;
		}
		else rdata[i].flag = IF_Missing;
	}
}

