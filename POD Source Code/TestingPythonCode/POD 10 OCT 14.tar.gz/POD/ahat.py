from math import *  # lint:ok
from funcr import *
from alogam import *
from betain import *
from phinv import *
from mdnord import *
from leqslv import *
from smtxinv import *
from sysolv import *

if __name__ == '__main__':
    print('alogam(23.2) ' + str(alogam(23.2)))
    print('betain(.1,.2,.3,.4) ' + str(betain(1, .2, .3, .4)))
    print('phint test')
    for i in range(11):
        if i == 0:
            x = 0.0001
        elif i == 10:
            x = 0.9999
        else:
            x = 0.1 * i
        y = phinv(x)
        print("%9.4f\t %18.12f" % (x, y))
    print('mdnord(23.2) ' + str(mdnord(23.2)))
    matrix = [[4, 2], [6, 1]]
    dd = [2, 1]
    print ['matrix' + str(matrix)]
    print ['vector' + str(dd)]
    print ['tdleq(matrix,vector)' + str(tdleq(matrix, dd))]

    x = [[2, 2, 3], [4, 5, 6], [7, 8, 9]]
    print ("x: " + str(x))

    xi = [[2, 2, 3], [4, 5, 6], [7, 8, 9]]
    print ("xi: " + str(xi))

    deter, xi = smtxinv(x, xi)

    print ("x = [[1,2,3],[4,5,6],[7,8,9]]")
    print ("deter, xi = smtxinv(x)")
    print ("deter: " + str(deter))
    print ("xi: " + str(xi))

    print ['leqslv(x,[3,8,4.2])' + str(leqslv(x, [3, 8, 4.2]))]







