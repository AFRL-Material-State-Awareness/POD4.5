from random import random  # lint:ok
from linreg import linear_regression
from sysolv import ahat_sysolv
from funcr import *
from math import sqrt, isnan
from phinv import phinv
from nrmden import nrmden
from alnorm import alnorm


def IsNumber(x):
    return not isnan(x)


class CAnal ():
    'Holds a given analysis'
    def __init__(self, flaw, data):
        self.flaw = flaw
        self.crksize = flaw.crksize
        self.crkf = flaw.crkf
        self.ybar = flaw.ybar
        self.ybar_inv = flaw.ybar_inv
        if data.ahat_model == NONLINEAR_MODEL:
            self.yfit = data.linfit[0] + data.linfit[1] * self.crkf / \
                (1.0 * data.linfit[3] * data.crkf)
        else:
            self.yfit = data.linfit[0] + data.linfit[1] * self.crkf
        self.yfit_inv = r_inv(self.yfit, data.transform)
        self.diff = self.ybar - self.yfit
        self.dstar = alnorm(self.diff / data.linfit[2], False)

##
##class CInfo():
##    'A stub for the CInfo class'
##    def __init__(self):
##        self.name = ""
##        self.row = 0
##        self.value = None
##        self.namecell = None
##        self.valuecell  = None
##
##    def IsNumber(self):
##        return IsNumber(self.valuecell)
##
##    def IsString(self):
##        return IsString(self.valuecell)
##
##    def __str__(self):
##        return str(self.name)+" "+str(self.value)
##

AHAT_ANALYSIS = 1
PF_ANALYSIS = 2

LINEAR_MODEL = 0
NONLINEAR_MODEL = 1
ODDS_MODEL = 2

XF_NONE = 1
XF_LOG = 2
XF_EXP = 3
XF_INVERSE = 4
XF_CUSTOM = 5

MAXINFO = 32

max_ath = 30

IF_Censored = 3
IF_Below = 2
IF_Above = 1
IF_Okay = 0
IF_Missing = -1

TRANS_NONE = 1
TRANS_LOG = 2
TRANS_EXP = 3
TRANS_RECIP = 4


class CDocument():
    'A stub for the CDocument class.  Dunno what this does.'


class CInspection():
    def __init__(self, value=0, flag=0, IsIncluded=True):
        self.value = value
        self.flag = flag
        self.IsIncluded = IsIncluded


class CrackData():
    'Holds info about a single crack'
    def __init__(self):
        self.crksize = 0  # Crack Size
        self.crkf = 0  # transformed crack size
        self.bValid = True
        self.rdata = []  # Raw measurements
        self.nsets = 0  # number of measurements
        self.count = 0  # number of inspections showing

        #// PassFail analysis
        self.above = 0

        #// Ahat analysis
        self.ybar = 0      # mean transformed ahat
        self.ybar_inv = 0  # mean untransformed ahat
        self.yfit = 0      # predicted transformed ahat
        self.yfit_inv = 0  # predicted untransformed ahat
        self.scnt = 0      # censoring value
        self.ssy = 0       # censoring?
        self.ncensor = 0   # censoring?
        self.transform = TRANS_NONE  # default to no transform

    def IsIncluded(self):  # Check to see if any measurement is uncensored
        included = [each.IsIncluded for each in self.rdata]
        return any(included)

    def crack_ahat_censor(self, data):
        i, j, n = 0, 0, 0
        value = 0
        acnt, bcnt, self.count = 0, 0, 0
        ybar = 0.0
        self.ncensor = 0
        for i in range(self.nsets):
            if not self.rdata[i].IsIncluded:
                self.rdata[i].flag = IF_Missing
                continue
            if not IsNumber(self.rdata[i].value)\
            or not IsNumber(self.crksize):
                self.rdata[i].flag = IF_Censored
                continue
            value = self.rdata[i].value
            self.count += 1
            if value <= data.tmin:
                bcnt += 1
                self.rdata[i].flag = IF_Below
            elif value >= data.tmax and data.tmax > data.tmin:
                acnt += 1
                self.rdata[i].flag = IF_Above
            else:
                self.rdata[i].flag = IF_Okay
        # If there are no inspection result values, set a flag and return
        if (self.count == 0):  # This is an ERROR condition
            self.ncensor = 6
            return
        # If there are inspection result values both above the saturation
        # and below the recording threshold for the same flaw, notify the
        # user and continue.
        if (acnt != 0 and bcnt != 0):  # This is an ERROR condition
            self.ncensor = 5
            return
        cnt = acnt + bcnt
        rmin = r_fwd(data.tmin, self.transform)
        rmax = r_fwd(data.tmax, self.transform)
        # if all the inspection results were censored ...
        if cnt == self.count:
            if acnt != 0:
                self.ybar = rmax
                self.ybar_inv = data.tmax
                self.ncensor = 1
            elif bcnt != 0:
                self.ybar = rmin
                self.ybar_inv = data.tmin
                self.ncensor = 2
            return

        r, ysum, ysqr = 0, 0, 0
        n = 0.0
        for j in range(self.nsets):
            if self.rdata[j].flag != IF_Okay:
                continue
            r = r_fwd(self.rdata[j].value, self.transform)
            ysum += r
            ysqr += r * r
            n += 1.0
        self.ybar = ysum / n
        self.ybar_inv = r_inv(self.ybar, self.transform)
        # if no values have been censored ...
        if cnt == 0:
            if n == 1:
                self.scnt = 1
            else:
                self.scnt = n - 1
            self.ssy = (ysqr - n * self.ybar * self.ybar)

            return
        # if some are censored either above or below
        pstar, theta, thab, sigmar, alpha, c = 0.0, 0.0, 0.0, 0.0, 0.0, 0.0
        self.scnt, self.ssy = 0.0, 0.0
        if acnt != 0:  # some but not all were above the max
            c = rmax
            pstar = float(acnt) / float(self.count)
            theta = phinv(pstar)
            thab = theta * (c - self.ybar)
            sigmar = (thab + sqrt(thab * thab
            + ((4.0 / n) * (ysqr + (n * c - 2.0 * ysum) * c)))) / 2.0
            alpha = self.count * nrmden(theta) / n
            ybar += alpha * sigmar
            self.ncensor = 3
        elif bcnt != 0:  # some but not all were below the min
            c = rmin
            pstar = float(bcnt) / float(self.count)
            theta = phinv(pstar)
            thab = theta * (ybar - c)
            sigmar = (thab + sqrt(thab * thab
            + ((4.0 / n) * (ysqr + (n * c - 2.0 * ysum) * c)))) / 2.0
            alpha = self.count * nrmden(theta) / n
            self.ybar -= alpha * sigmar
            self.ncensor = 4
        else:  # This is an ERROR condition
            self.ncensor = 7
        self.ybar_inv = r_inv(self.ybar, self.transform)

    ## def pf_censor(double tmin)
    ## def ahat_write(int row, int col)
    ## def IsNumber() { return (V_VT(&size)==VT_R8) }
    ## def IsIncluded() { return (bValid && V_I4(&ColorIndex)==xlNone) }


class CPodDoc(CDocument):
    'A dummy CPodDoc class for testing purposes'
    def __init__(self):
        self.podfile = None  # use this to hold the filename??
        # self.v OLEVariant - Used this to hold file descriptor
        self.info = []
        self.info_count = 0

        # Info Worksheet access
        self.info_row = 0
        self.analysis = 0  # 0 = ahat, 1 = pass/fail
        self.model = 0  # 0 - linear, 1 = rational
        self.flaw_name = ''
        self.flaw_column = 0
        self.flaw_units = ''
        self.data_column = 0
        self.data_units = ''
        self.tmin = 0
        self.tmax = 0
        self.amax = 0

        # list of decision thresholds
        #GetAth(row)
        self.nath = 0
        self.ath = []
        self.pod_threshold = 0

        #Data worksheet
        self.titles = []
        self.nrows = 0
        self.ncols = 0
        self.flaws = []
        self.nsets = 0
        self.count = 0

        #Flaw range
        self.crkmin = 0
        self.crkmax = 0
        self.xmin = 0
        self.xmax = 0

        #input to regression routine  (rlonx[nrows], rlony[nrows])
        self.rlonx = []
        self.rlony = []
        self.pfdata = []
        self.npts = 0

        # cracks with all inspections above saturation or below threshold
        self.acount = 0  # number of cases with all inspections at maximum
        self.bcount = 0  # number with all at minimum

        #cacks excluded from the analysis
        nexcluded = 0

        #POD parameter intial guess
        self.have_guess = False
        self.mu_guess = 0.0
        self.sig_guess = 0.0

        #POD model parameters
        self.sighat = 0.0
        self.muhat = 0.0

        #Confidence bounds settings  a9095 = crack size 95% confidence
        #(confidence_level) for 90% pod (pod_level = 0.9)
        self.pod_level = 0
        self.confidence_level = 0
        self.asize = ''  # e.g. a90
        self.alevel = ''  # e.g. a90/95
        self.clevel = ''  # e.g. 95% confidence bound

        self.a_opt = 0
        self.r_opt = 0
        self.a_row = 0

        self.linfit = [0, 0, 0]
        self.var = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
        self.iret = 0
        self.fnorm = 0
        self.jb = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
        self.res_sums = [0, 0, 0]

        self.analyses = []
        self.transform = TRANS_NONE
        ##cbound(npts)

        self.PlotTitle = ''
        ##BuildTitle()
        ##ResidualsChart()
        ##FitChart()
        ##ThresholdChart()
        ##PODChart()
        ##AhatChart()

        ##XlOpen(CString filepath)
        ##OnFileNew()
        ##OnFileImport()

        #// Ahat analysis
        ##ahat_residuals()
        ##ahat_censor()
        ##ahat_solve()
        ##ahat_nonlinear_solve()
        ##ahat_tests()
        ##ahat_print()
        ##ahat_decision()
        ##ahat_pod()

        #// Pass/Fail analysis
        ##pf_censor()
        ##pf_guess()
        ##pf_residuals()
        ##pf_solve()
        ##pf_p rint()
        ##pf_pod()
        self.SortData()

    def get_transform(self):
        if len(self.flaws) != 0:
            return self.flaws[0].transform
        else:
            return self.transform

    def example2(self):
        lcrk = [6, 7, 8, 8, 8, 8, 8, 8, 9, 9, 9, 10, 10, 10, 10, 11, 11, 11,
            11, 11, 11, 11, 12, 12, 12, 13, 13, 13, 13, 14, 14, 15, 15, 15, 16,
            16, 17, 18, 18, 20, 20, 21, 25]
        meas = {
        'A11': [130, 104, 118, 115, 147, 143, 154, 95, 138, 181, 218, 154, 216,
            87, 229, 201, 262, 215, 261, 334, 397, 320, 283, 362, 457, 330,
            303, 506, 312, 428, 503, 524, 430, 616, 523, 577, 572, 603, 623,
            1012, 928, 862, 1804],
        'A21': [94, 108, 139, 122, 131, 130, 174, 50, 136, 190, 191, 149, 205,
            220, 273, 157, 305, 186, 210, 345, 323, 324, 282, 331, 358, 282,
            300, 432, 316, 465, 388, 441, 384, 619, 470, 598, 482, 635, 634,
            941, 922, 798, 1547],
        'A31':
            [106, 86, 108, 114, 138, 134, 126, 70, 138, 122, 169, 138, 186,
            223, 214, 132, 251, 169, 205, 291, 304, 283, 273, 333, 333, 302,
            270, 399, 290, 402, 404, 406, 382, 484, 435, 566, 485, 576, 547,
            864, 876, 722, 1543]}
        self.flaws = []
        for index in range(len(lcrk)):
            crack = CrackData()
            crack.crksize = float(lcrk[index])
            crack.rdata = []
            for key in meas.keys():
                an_inspection = CInspection(float(meas[key][index]))
                crack.rdata += [an_inspection]
            crack.transform = self.get_transform()
            crack.crkf = funcr(crack.crksize, crack.transform)
            if not IsNumber(crack.crkf):
                crack.bValid = False
            crack.nsets = len(crack.rdata)
            included = [each for each in crack.rdata if each.IsIncluded]
            crack.count = len(included)
            r, ysum, ysqr = 0, 0, 0
            n = 0.0
            for each in crack.rdata:
                r = r_fwd(each.value, crack.transform)
                ysum += r
                ysqr += r * r
                n += 1.0
            crack.ybar = ysum / n
            crack.ybar_inv = r_inv(crack.ybar, crack.transform)
            self.flaws += [crack]

        self.rlonx = [each.crkf for each in self.flaws]
        self.rlony = [each.ybar for each in self.flaws]

    def ahat_censor(self):
        self.ssy, self.scnt = 0.0, 0.0
        self.npts = 0
        self.ahat_model = self.model
        self.nrows = len(self.flaws)
        self.rlonx = []
        self.rlony = []
        for i in range(self.nrows):
            pdata = self.flaws[i]
            pdata.crack_ahat_censor(self)

            if not pdata.IsIncluded() or pdata.count == 0:
                print("something stinks")
                continue
            if pdata.ncensor == 0 \
            or pdata.ncensor == 3 \
            or pdata.ncensor == 4:
                self.rlonx += [pdata.crkf]
                self.rlony += [pdata.ybar]
                self.npts += 1
                self.scnt += pdata.scnt
                self.ssy += pdata.ssy
            elif pdata.ncensor == 1:  # all above max
                self.acount += 1
            elif pdata.ncensor == 2:  # all below min
                self.bcount += 1

        self.SortData()
        npts2 = self.npts
        if self.acount != 0:
            for i in range(self.nrows):
                pdata = self.flaws[i]
                if not pdata.IsIncluded():
                    continue
                if pdata.ncensor != 1:
                    continue
                self.rlonx += [pdata.crkf]
                self.rlony += [pdata.ybar]
                npts2 += 1

        if self.bcount != 0:
            for i in range(self.nrows):
                pdata = self.flaws[i]
                if not pdata.IsIncluded():
                    continue
                if pdata.ncensor != 2:
                    continue
                self.rlonx += [pdata.crkf]
                self.rlony += [pdata.ybar]
                npts2 += 1

        if not npts2 == self.npts + self.acount + self.bcount:
            #make sure we counted every flaw
            print("Something didn't work below")
            print(npts2)
            print(self.npts)
            print(self.acount)
            print(self.bcount)
            print("Something didn't work")

    def ahat_solve(self):
        self.iret = 0
        self.fnorm = 0
        lr = linear_regression()

        #// first pass -
        #// generate initial guess using all data,
        # including values with censored y's
        npts2 = self.npts + self.acount + self.bcount
        lr.regress(self.rlonx, self.rlony, npts2)
        self.linfit = [lr.intercept, lr.slope, lr.rms]
        self.var = [[0, 0, 0], [0, 0, 0], [0, 0, 0]]
        self.iret = ahat_sysolv(self)
        if (not self.iret):
            return 0
        ##("Pass 1 Ahat analysis error return %d\n", iret)

        #// second pass
        #// generate initial guess using only uncensored values
        lr.regress(self.rlonx, self.rlony, self.npts)
        self.linfit = [lr.intercept, lr.slope, lr.rms]
        self.iret = ahat_sysolv(self.linfit, self.var, self.fnorm, self)
        if (not self.iret):
            return 0

        ##TRACE("Pass 2 Ahat analysis error return %d\n", iret)
        return -1

    def SortData(self):
        from qsort import qsort
        qsort(self.flaws)

    def OnAnalysis(self):
        ##ahat_model = self.model

        if (self.analysis == AHAT_ANALYSIS):
            self.ahat_censor()    # defined in ahat.cpp
            self.GetCrackRange()  # defined in CrackData.cpp
            #self.ShowInfo()                 #defined in Info.cpp
        if (self.model == NONLINEAR_MODEL):
            self.ahat_nonlinear_solve()
        else:
            self.ahat_solve()  # defined in ahat.cpp
        self.ahat_residuals()
        ##self.ahat_print()

    def GetCrackRange(self):
        first = True
        if self.nrows == 0:
            return
        for crack in self.flaws:
            if not crack.IsIncluded():
                continue
            if first is True:
                self.crkmin = crack.crksize
                self.crkmax = crack.crksize
                first = False
            else:
                if (crack.crksize < self.crkmin):
                    self.crkmin = crack.crksize
                elif (crack.crksize > self.crkmax):
                    self.crkmax = crack.crksize

        first = True
        for crack in self.flaws:
            if not crack.IsIncluded():
                continue
            if crack.count == 0:
                continue
            if first is True:
                self.xmin = crack.crksize
                self.xmax = crack.crksize
                first = False
            else:
                if crack.crksize > self.xmax:
                    self.xmax = crack.crksize
                if crack.crksize < self.xmin:
                    self.xmin = crack.crksize

    def ahat_residuals(self):
        #// Calculate extremes of fit
        x1 = a_fwd(self.xmin, self.transform)
        y1 = self.linfit[0] + self.linfit[1] * x1
        tlimit = r_inv(y1, self.transform)
        if (tlimit < self.tmin):
            y1 = r_fwd(self.tmin, self.transform)
            x1 = (y1 - self.linfit[0]) / self.linfit[1]
        if (self.tmax > self.tmin):
            if (tlimit > self.tmax):
                y1 = r_fwd(tmax, self.transform)
                x1 = (y1 - self.linfit[0]) / self.linfit[1]
        x2 = a_fwd(self.xmax, self.transform)
        y2 = self.linfit[0] + self.linfit[1] * x2
        tlimit = r_inv(y2, self.transform)

        if (tlimit < self.tmin):
            y2 = r_fwd(self.tmin, self.transform)
            x2 = (y2 - self.linfit[0]) / self.linfit[1]
        if (self.tmax > self.tmin):
            if (tlimit > self.tmax):
                y2 = r_fwd(self.tmax, self.transform)
                x2 = (y2 - self.linfit[0]) / self.linfit[1]
        if (self.a_opt <= XF_LOG):
            x1 = a_inv(x1, self.transform)
            x2 = a_inv(x2, self.transform)
        if (self.r_opt <= XF_LOG):
            y1 = r_inv(y1, self.transform)
            y2 = r_inv(y2, self.transform)

        self.analyses = []
        i = 0

        for each in self.flaws:
            if not each.IsIncluded or each.count == 0:
                continue
            if each.ncensor == 0 \
            or each.ncensor == 3 \
            or each.ncensor == 4:
                self.analyses += [CAnal(each, self)]

        if len(self.analyses) != self.npts:
            print("Something Stinks!")

        for each in self.flaws:
            if each.bValid:
                continue
            x = each.crkf
            y = self.linfit[0] + self.linfit[1] * x
            each.yfit = y
            each.yfit_inv = r_inv(y, self.transform)

        nexcluded = 0
        for each in self.flaws:
            if not each.IsIncluded or each.count == 0:
                continue
            if each.ncensor == 1 \
            or each.ncensor == 2:
                self.analyses += [CAnal(each, self)]
                nexcluded += 1

        if len(self.analyses) != (self.npts + self.acount + self.bcount):
            print("Something Stinks!")
            print("self.analyses", self.analyses)
            print("!=")
            print("self.npts +", self.npts)
            print("self.acount", self.acount)
            print("self.bcount", self.bcount)

if __name__ == '__main__':

    pDoc = CPodDoc()
    pDoc.analysis = AHAT_ANALYSIS
    pDoc.transform = TRANS_LOG
    pDoc.example2()

    ##pDoc.rlonx = [each.crksize for each in pDoc.flaws]
    ##pDoc.rlony = [each.rdata[0].value for each in pDoc.flaws]

    pDoc.tmin = min(pDoc.rlony) + 100
    pDoc.tmax = max(pDoc.rlony) - 1000
    pDoc.OnAnalysis()

    print[(each.crksize, each.crkf) for each in pDoc.flaws]

    import podplot
    myfit = [pDoc.linfit[0] + pDoc.linfit[1] * each for each in pDoc.rlonx]
    import copy
    xdata = copy.deepcopy(pDoc.rlonx)
    xdata.sort()
    ydata = copy.deepcopy(myfit)
    ydata.sort()
    podplot.fit((pDoc.rlonx, pDoc.rlony), (xdata, ydata, pDoc.linfit[2]))
    myresid = [pDoc.rlony[i] - myfit[i] for i in range(len(myfit))]
    podplot.resid((pDoc.rlonx, myresid))

